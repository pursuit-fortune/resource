// 定义年、月、日的数组都为空
const date = new Date()
const years = []
const months = []
const days = []
// 获取年
for (let i = 1990; i <= date.getFullYear(); i++) {
  years.push(i)
}
// 获取月份
for (let i = 1; i <= 12; i++) {
  months.push(i)
}
// 获取日期
for (let i = 1; i <= 31; i++) {
  days.push(i)
}

Page({
  // 初始默认的日期
  data: {
    years,
    year: date.getFullYear(),
    months,
    month: 0,
    days,
    day: 0,
    value: [9999, 1, 1],
    timePickerStatus:false,
  },
  // 获取改变后的日期
  bindChange(e) {
    const val = e.detail.value
    this.setData({
      year: this.data.years[val[0]],
      month: this.data.months[val[1]],
      day: this.data.days[val[2]]
    })
  },
  //日期选择器消失
  timePickerHide:function(){
    this.setData({
      timePickerStatus: false
    });
  },
  timePickerShow:function(){
    this.setData({
      timePickerStatus: true
    });
  },
  nextAction:function(){
    wx:wx.navigateTo({
      url: '../index/index',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  }
})
